package ca.ubc.cs.cpsc210.translink.parsers;

import ca.ubc.cs.cpsc210.translink.model.Route;
import ca.ubc.cs.cpsc210.translink.model.RouteManager;
import ca.ubc.cs.cpsc210.translink.model.RoutePattern;
import ca.ubc.cs.cpsc210.translink.parsers.exception.RouteDataMissingException;
import ca.ubc.cs.cpsc210.translink.providers.DataProvider;
import ca.ubc.cs.cpsc210.translink.providers.FileDataProvider;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

// The whole class is implemented by me except for the parse() method

/**
 * Parse route information in JSON format.
 */
public class RouteParser {
    private String filename;
    private String name;
    private String number;

    public RouteParser(String filename) {
        this.filename = filename;
    }

    /**
     * Parse route data from the file and add all route to the route manager.
     */
    public void parse() throws IOException, RouteDataMissingException, JSONException {
        DataProvider dataProvider = new FileDataProvider(filename);

        parseRoutes(dataProvider.dataSourceToString());
    }

    /**
     * Parse route information from JSON response produced by Translink.
     * Stores all routes and route patterns found in the RouteManager.
     *
     * @param jsonResponse string encoding JSON data to be parsed
     * @throws JSONException             when JSON data does not have expected format
     * @throws RouteDataMissingException when
     *                                   <ul>
     *                                   <li> JSON data is not an array </li>
     *                                   <li> JSON data is missing Name, StopNo, Routes or location elements for any stop</li>
     *                                   </ul>
     */

    public void parseRoutes(String jsonResponse)
            throws JSONException, RouteDataMissingException {

        JSONArray array = new JSONArray(jsonResponse);
        try {
            for (int index = 0; index < array.length(); index++) {
                JSONObject route = array.getJSONObject(index);
                parseRoute(route);
            }
        } catch (JSONException e) {
            throw new RouteDataMissingException();
        }
    }

    /**
     * Parse a route
     *
     * @param route string encoding JSON data to be parsed
     * @throws RouteDataMissingException JSON data is missing RouteNo, Name, or Patterns elements for any route
     *                                   The value of the Patterns element is not an array for any route
     * @throws JSONException             when JSON data does not have expected format
     */
    private void parseRoute(JSONObject route) throws RouteDataMissingException, JSONException {
        name = route.getString("Name");
        number = route.getString("RouteNo");
        JSONArray patterns = route.getJSONArray("Patterns");


        for (int index = 0; index < patterns.length(); index++) {
            JSONObject pattern = patterns.getJSONObject(index);
            parsePattern(pattern);
        }

    }

    /**
     * Parse a route pattern
     *
     * @param pattern string encoding JSON data to be parsed
     * @throws RouteDataMissingException JSON data is missing PatternNo, Destination, or Direction elements
     *                                   for any route pattern
     * @throws JSONException             when JSON data does not have expected format
     */
    private void parsePattern(JSONObject pattern) throws RouteDataMissingException, JSONException {
        String patternName = pattern.getString("PatternNo");
        String destination = pattern.getString("Destination");
        String direction = pattern.getString("Direction");

        this.storeRoute(patternName, destination, direction);


    }

    /**
     * Store data in in the route manager
     *
     * @param patternName the name of the RoutePattern
     * @param destination the destination of the bus
     * @param direction   the direction of the route
     */

    private void storeRoute(String patternName, String destination, String direction) {
        Route r = RouteManager.getInstance().getRouteWithNumber(number);
        r.setName(name);
        RoutePattern rp = r.getPattern(patternName);
        rp.setDirection(direction);
        rp.setDestination(destination);
        r.addPattern(rp);
    }
}
