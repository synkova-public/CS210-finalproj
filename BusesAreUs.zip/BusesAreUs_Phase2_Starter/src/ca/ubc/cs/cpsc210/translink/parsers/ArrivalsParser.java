package ca.ubc.cs.cpsc210.translink.parsers;

import ca.ubc.cs.cpsc210.translink.model.Arrival;
import ca.ubc.cs.cpsc210.translink.model.Route;
import ca.ubc.cs.cpsc210.translink.model.RouteManager;
import ca.ubc.cs.cpsc210.translink.model.Stop;
import ca.ubc.cs.cpsc210.translink.parsers.exception.ArrivalsDataMissingException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

// The whole class is implemented by me

/**
 * A parser for the data returned by the Translink arrivals at a stop query
 */
public class ArrivalsParser {

    /**
     * Parse arrivals from JSON response produced by TransLink query.  All parsed arrivals are
     * added to the given stop assuming that corresponding JSON object has a RouteNo: and an
     * array of Schedules:
     * Each schedule must have an ExpectedCountdown, ScheduleStatus, and Destination.  If
     * any of the aforementioned elements is missing, the arrival is not added to the stop.
     *
     * @param stop         stop to which parsed arrivals are to be added
     * @param jsonResponse the JSON response produced by Translink
     * @throws JSONException                when JSON response does not have expected format
     * @throws ArrivalsDataMissingException when no arrivals are found in the reply
     */
    public static void parseArrivals(Stop stop, String jsonResponse)
            throws JSONException, ArrivalsDataMissingException {
        JSONArray array = new JSONArray(jsonResponse);
        int expectedCountdown;
        String destination;
        Arrival arrival;

        try {
            for (int index = 0; index < array.length(); index++) {
                JSONObject a = array.getJSONObject(index);
                String routeNo = a.getString("RouteNo");
                Route route = RouteManager.getInstance().getRouteWithNumber(routeNo);
                route.setName(a.getString("RouteName"));
                route.addStop(stop);
                JSONArray schedules = a.getJSONArray("Schedules");

                for (int i = 0; i < schedules.length(); i++) {
                    JSONObject sch = schedules.getJSONObject(i);
                    expectedCountdown = sch.getInt("ExpectedCountdown");
                    destination = sch.getString("Destination");
                    arrival = new Arrival(expectedCountdown, destination, route);
                    arrival.setStatus(sch.getString("ScheduleStatus"));
                    stop.addArrival(arrival);
                }
            }
        } catch (JSONException e) {
            throw new ArrivalsDataMissingException();
        }
    }
}
