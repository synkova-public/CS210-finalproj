package ca.ubc.cs.cpsc210.translink.parsers;

import ca.ubc.cs.cpsc210.translink.model.Route;
import ca.ubc.cs.cpsc210.translink.model.RouteManager;
import ca.ubc.cs.cpsc210.translink.model.Stop;
import ca.ubc.cs.cpsc210.translink.model.StopManager;
import ca.ubc.cs.cpsc210.translink.parsers.exception.StopDataMissingException;
import ca.ubc.cs.cpsc210.translink.providers.DataProvider;
import ca.ubc.cs.cpsc210.translink.providers.FileDataProvider;
import ca.ubc.cs.cpsc210.translink.util.LatLon;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

// The whole class is implemented by me except for the parse() method

/**
 * A parser for the data returned by Translink stops query
 */
public class StopParser {

    private String filename;
    private String routes;

    public StopParser(String filename) {
        this.filename = filename;
    }

    /**
     * Parse stop data from the file and add all stops to stop manager.
     */
    public void parse() throws IOException, StopDataMissingException, JSONException {
        DataProvider dataProvider = new FileDataProvider(filename);

        parseStops(dataProvider.dataSourceToString());
    }

    /**
     * Parse stop information from JSON response produced by Translink.
     * Stores all stops and routes found in the StopManager and RouteManager.
     *
     * @param jsonResponse string encoding JSON data to be parsed
     * @throws JSONException            when JSON data does not have expected format
     * @throws StopDataMissingException when
     *                                  <ul>
     *                                  <li> JSON data is not an array </li>
     *                                  <li> JSON data is missing Name, StopNo, Routes or location (Latitude or Longitude) elements for any stop</li>
     *                                  </ul>
     */

    public void parseStops(String jsonResponse)
            throws JSONException, StopDataMissingException {
        JSONArray array = new JSONArray(jsonResponse);
        try {
            for (int index = 0; index < array.length(); index++) {
                JSONObject stop = array.getJSONObject(index);
                parseStop(stop);
            }
        } catch (JSONException e) {
            throw new StopDataMissingException();
        }
    }

    private void parseStop(JSONObject stop) throws JSONException, StopDataMissingException {
        String name = stop.getString("Name");
        int number = stop.getInt("StopNo");
        double lat = stop.getDouble("Latitude");
        double lon = stop.getDouble("Longitude");
        routes = stop.getString("Routes");
        LatLon coord = new LatLon(lat, lon);

        this.storeStop(name, number, coord);
    }

    private void storeStop(String name, int number, LatLon coord) {
        Stop s = StopManager.getInstance().getStopWithId(number);
        String[] array = routes.split(",");
        for (int index = 0; index < array.length; index++) {
            String routeNumber = array[index];
            Route r = RouteManager.getInstance().getRouteWithNumber(routeNumber);
            s.addRoute(r);
            r.addStop(s);
        }
        s.setName(name);
        s.setLocn(coord);
    }
}
