package ca.ubc.cs.cpsc210.translink.util;

// Implemented by me

/**
 * Compute relationships between points, lines, and rectangles represented by LatLon objects
 */
public class Geometry {
    /**
     * Return true if the point is inside of, or on the boundary of, the rectangle formed by northWest and southeast
     * @param northWest         the coordinate of the north west corner of the rectangle
     * @param southEast         the coordinate of the south east corner of the rectangle
     * @param point             the point in question
     * @return                  true if the point is on the boundary or inside the rectangle
     */
    public static boolean rectangleContainsPoint(LatLon northWest, LatLon southEast, LatLon point) {
        return between(northWest.getLongitude(), southEast.getLongitude(), point.getLongitude()) &&
                between(southEast.getLatitude(), northWest.getLatitude(), point.getLatitude());
    }

    /**
     * Return true if the rectangle intersects the line
     * @param northWest         the coordinate of the north west corner of the rectangle
     * @param southEast         the coordinate of the south east corner of the rectangle
     * @param src               one end of the line in question
     * @param dst               the other end of the line in question
     * @return                  true if any point on the line is on the boundary or inside the rectangle
     */
    public static boolean rectangleIntersectsLine(LatLon northWest, LatLon southEast, LatLon src, LatLon dst) {
        return (between(southEast.getLatitude(), northWest.getLatitude(), src.getLatitude()) &&
                between(southEast.getLongitude(), northWest.getLongitude(), dst.getLongitude())) ||

                (between(southEast.getLatitude(), northWest.getLatitude(), src.getLatitude()) &&
                        between(southEast.getLatitude(), northWest.getLatitude(), dst.getLatitude())) ||

                (between(southEast.getLongitude(), northWest.getLongitude(), src.getLongitude()) &&
                        between(southEast.getLongitude(), northWest.getLongitude(), dst.getLongitude()));
    }

    // Provided by the UBC CS department

    /**
     * A utility method that you might find helpful in implementing the two previous methods
     * Return true if x is >= lwb and <= upb
     * @param lwb      the lower boundary
     * @param upb      the upper boundary
     * @param x         the value in question
     * @return          true if x is >= lwb and <= upb
     */
    private static boolean between(double lwb, double upb, double x) {
        return lwb <= x && x <= upb;
    }
}
